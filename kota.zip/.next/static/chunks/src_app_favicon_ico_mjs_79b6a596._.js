(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_favicon_ico_mjs_79b6a596._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_favicon_ico_mjs_79b6a596._.js",
  "chunks": [
    "static/chunks/node_modules_next_dist_1a6ee436._.js"
  ],
  "source": "dynamic"
});
